(function() {
	const e = "https://unpkg.com/@ffmpeg/core@0.12.9/dist/umd/ffmpeg-core.js";
	var t;
	(function(e) {
		e.LOAD = "LOAD", e.EXEC = "EXEC", e.FFPROBE = "FFPROBE", e.WRITE_FILE = "WRITE_FILE", e.READ_FILE = "READ_FILE", e.DELETE_FILE = "DELETE_FILE", e.RENAME = "RENAME", e.CREATE_DIR = "CREATE_DIR", e.LIST_DIR = "LIST_DIR", e.DELETE_DIR = "DELETE_DIR", e.ERROR = "ERROR", e.DOWNLOAD = "DOWNLOAD", e.PROGRESS = "PROGRESS", e.LOG = "LOG", e.MOUNT = "MOUNT", e.UNMOUNT = "UNMOUNT";
	})(t || (t = {}));
	const r = /* @__PURE__ */ new Error("unknown message type"), a = /* @__PURE__ */ new Error("ffmpeg is not loaded, call `await ffmpeg.load()` first"), s = /* @__PURE__ */ new Error("failed to import ffmpeg-core.js");
	let o;
	self.onmessage = async ({ data: { id: E, type: n, data: c } }) => {
		const i = [];
		let R;
		try {
			if (n !== t.LOAD && !o) throw a;
			switch (n) {
				case t.LOAD:
					R = await (async ({ coreURL: r, wasmURL: a, workerURL: E }) => {
						const n = !o;
						try {
							r || (r = e), importScripts(r);
						} catch {
							if (r && r !== e || (r = e.replace("/umd/", "/esm/")), self.createFFmpegCore = (await import(r)).default, !self.createFFmpegCore) throw s;
						}
						const c = r, i = a || r.replace(/.js$/g, ".wasm"), R = E || r.replace(/.js$/g, ".worker.js");
						return o = await self.createFFmpegCore({ mainScriptUrlOrBlob: `${c}#${btoa(JSON.stringify({
							wasmURL: i,
							workerURL: R
						}))}` }), o.setLogger((e) => self.postMessage({
							type: t.LOG,
							data: e
						})), o.setProgress((e) => self.postMessage({
							type: t.PROGRESS,
							data: e
						})), n;
					})(c);
					break;
				case t.EXEC:
					R = (({ args: e, timeout: t = -1 }) => {
						o.setTimeout(t), o.exec(...e);
						const r = o.ret;
						return o.reset(), r;
					})(c);
					break;
				case t.FFPROBE:
					R = (({ args: e, timeout: t = -1 }) => {
						o.setTimeout(t), o.ffprobe(...e);
						const r = o.ret;
						return o.reset(), r;
					})(c);
					break;
				case t.WRITE_FILE:
					R = (({ path: e, data: t }) => (o.FS.writeFile(e, t), !0))(c);
					break;
				case t.READ_FILE:
					R = (({ path: e, encoding: t }) => o.FS.readFile(e, { encoding: t }))(c);
					break;
				case t.DELETE_FILE:
					R = (({ path: e }) => (o.FS.unlink(e), !0))(c);
					break;
				case t.RENAME:
					R = (({ oldPath: e, newPath: t }) => (o.FS.rename(e, t), !0))(c);
					break;
				case t.CREATE_DIR:
					R = (({ path: e }) => (o.FS.mkdir(e), !0))(c);
					break;
				case t.LIST_DIR:
					R = (({ path: e }) => {
						const t = o.FS.readdir(e), r = [];
						for (const a of t) {
							const t = o.FS.stat(`${e}/${a}`), s = o.FS.isDir(t.mode);
							r.push({
								name: a,
								isDir: s
							});
						}
						return r;
					})(c);
					break;
				case t.DELETE_DIR:
					R = (({ path: e }) => (o.FS.rmdir(e), !0))(c);
					break;
				case t.MOUNT:
					R = (({ fsType: e, options: t, mountPoint: r }) => {
						const a = e, s = o.FS.filesystems[a];
						return !!s && (o.FS.mount(s, t, r), !0);
					})(c);
					break;
				case t.UNMOUNT:
					R = (({ mountPoint: e }) => (o.FS.unmount(e), !0))(c);
					break;
				default: throw r;
			}
		} catch (p) {
			self.postMessage({
				id: E,
				type: t.ERROR,
				data: p.toString()
			});
			return;
		}
		R instanceof Uint8Array && i.push(R.buffer), self.postMessage({
			id: E,
			type: n,
			data: R
		}, i);
	};
})();
